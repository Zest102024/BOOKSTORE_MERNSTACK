import React, { useState, useEffect } from 'react';
import styles from "../styles/manageaccount.module.css";

function ManageAccount() {
    const [user, setUser] = useState({
        name: '',
        email: '',
        membership: '',
        borrowingHistory: [],
        activeRentals: [],
    });

    useEffect(() => {
        
      // Fetch user details from backend API
        const fetchUserData = async () => {
            try {
                const response = await fetch('/api/user/profile'); // Replace with your API endpoint
                const data = await response.json();
                setUser(data);
            } catch (error) {
                console.error("Error fetching user data:", error);
            }
        };

        fetchUserData();
    }, []);

    const handleEditProfile = () => {
        // Redirect to edit profile page or show an editable form
        console.log("Edit profile clicked");
    };

    return (
        <div className={styles.manageAccount}>
            <h1>My Profile</h1>

            <section className={styles.userInfo}>
                <h2>Profile Information</h2>
                <p><strong>Name:</strong> {user.name}</p>
                <p><strong>Email:</strong> {user.email}</p>
                <p><strong>Membership:</strong> {user.membership}</p>

                <button onClick={handleEditProfile} className={styles.btnEdit}>Edit Profile</button>

            </section>

            <section className={styles.borrowingHistory}>

                <h2>Borrowing History</h2>
                {user.borrowingHistory.length > 0 ? (
                    <ul>
                        {user.borrowingHistory.map((book, index) => (
                            <li key={index}>
                                <strong>{book.title}</strong> - {book.genre}
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p>No borrowing history yet.</p>
                )}
            </section>

            <section className={styles.activeRentals}>

                <h2>Active Rentals</h2>
                {user.activeRentals.length > 0 ? (
                    <ul>
                        {user.activeRentals.map((rental, index) => (
                            <li key={index}>
                                <strong>{rental.title}</strong> - Due: {rental.dueDate}
                                <button className={styles.btnReturn}>Return</button>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p>No active rentals.</p>
                )}
                
            </section>
        </div>
    );
}

export default ManageAccount;

