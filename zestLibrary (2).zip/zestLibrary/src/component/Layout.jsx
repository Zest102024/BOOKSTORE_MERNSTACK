import React, {useState} from "react";
import { Outlet } from "react-router-dom";
import Navigation from "./Navigation";
import classes from "../styles/layout.module.css";






const Layout = () => {


const [isLoggedIn, setIsLoggedIn] = useState(false);

const handleSignOut = () => {

  setIsLoggedIn(false);
  console.log("User signed out");

};




return (
  <main>
    <header>
      <Navigation isLoggedIn={isLoggedIn} handleSignOut={handleSignOut}/>
    </header>
    <hr />
    <div>
      <Outlet />
    </div>
    <footer className={classes.footer}>
      <p>
        @ {new Date().getFullYear()} Zest Library. All rights reserved. | 
        <a href="/teamMembers" className={classes.link}> Designed by Zest Group</a> |
        <a href="/privacy" className={classes.link}> Privacy Policy</a>
      </p>

    </footer>
    </main>
 );

};

export default Layout;
