import classes from "../styles/home.module.css";
import picture from "../assets/zest picture.webp";
import {useNavigate} from "react-router-dom";


const Home = () => {


const navigate = useNavigate();

const handleSignIn = () => {
  navigate("/signin")

};

const handleCreateAccount = () => {
  navigate("/signup");

};



  return (
    <main className={classes.container}>

      <div>
        <img className={classes.imagebox} src={picture} alt="" />
      </div>

      <div className={classes.textbox}>
        <div>
          <h2>ZEST LIBRARY</h2>
          <p>
            your ultimate destination for discoursing and borrowing books across
            all your favourite genres. whether you're into thrilling mysteries,
            heartwarming romances, insightful non-fictic, or captivating science
            fiction, our extensive collection has something for every reader.
          </p>
        </div>
        
        <div>
          <h2>Find a Book Now!</h2>

          <div className={classes.buttoncontainer}>
            <button className={classes.btn} onClick={handleSignIn}>Sign In</button>
            <button className={classes.btn} onClick={handleCreateAccount}>Create an Account</button>
          </div>

        </div>
      </div>
    </main>
  );
};

export default Home;
