import React from "react";
import classes from "../styles/navigation.module.css";
import { Link, useLocation } from "react-router-dom";
import zestlogo from "../assets/Zestlogo.png";

const navLinks = [
  {
    name: "MY PROFILE",
    href: "/manage-account",
  },
  {
    name: "RENT BOOK",
    href: "/rent-Book",
  },
  {
    name: "LOCATIONS",
    href: "/Locations",
  },
];

const Navigation = ({ isLoggedIn, handleSignOut }) => {
  const location = useLocation();

  return (
    <div className={classes.container}>

      <div>
        <Link to="/">
          <img className={classes.image} src={zestlogo} alt="Zest Logo" />
        </Link>
      </div>

      <ul className={classes.linkbox}>

        {/* Map through static navigation links */}
        {navLinks.map((link, index) => (
          <li key={index}>

            <Link
              className={`${classes.links} ${
                location.pathname === link.href ? classes.active : ""
              }`}
              to={link.href}> {link.name}
            </Link>

          </li>
        ))}

        {/* Conditional rendering based on login state*/}
        
        {isLoggedIn ? (
          <>
            <li>

              <Link
                className={`${classes.links} ${
                  location.pathname === "/profile" ? classes.active : "" }`} to="/profile">
                My Profile
              </Link>
            </li>

            <li>
              <button
                onClick={handleSignOut}
                className={`${classes.links} ${classes.signoutButton}`} >
                Sign Out
              </button>
            </li>
          </>
        ) : (
          <>
            <li>

              <Link
                className={`${classes.links} ${
                  location.pathname === "/signin" ? classes.active : "" }`} to="/signin">
                SIGN IN
              </Link>
              
            </li>
            <li>

              <Link
                className={`${classes.links} ${
                  location.pathname === "/signup" ? classes.active : "" }`} to="/signup">
                SIGN UP
              </Link>

            </li>
          </>
        )}
      </ul>
    </div>
  );
};

export default Navigation;
