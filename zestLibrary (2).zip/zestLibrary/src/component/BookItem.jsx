
const BookItem = ({book, onBookClick}) => {
    
    return (
        <div style={{margin: "10px", textAlign: "center", cursor: "pointer"}}

        onClick={() => onBookClick(book)} >
            <img src={book.image} alt={book.title}  style={{width: "150px", height: "150px", height: "200px", objectFit: "cover", marginBottom: "10px" }} />
            <h3>{book.title}</h3>
        </div>
    );

};

export default BookItem; 
