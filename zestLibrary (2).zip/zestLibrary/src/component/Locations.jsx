const Locations = () => {
  return <div>Location</div>;
};

export default Locations;
