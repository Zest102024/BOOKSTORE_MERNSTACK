import styles from "../styles/modal.module.css";

const Modal = ({book, onClose }) => {

    if (!book) return null;

    return (
        <div className={styles.overlay} onClick={onClose}>
            <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
                <button className={styles.closeButton} onClick={onClose}>
                    &times;
                </button>
                <img 
                src={book.image}
                alt={book.title}
                style={{width: "150px", height: "200px", objectFit: "cover"}} />
    
                <h2 className={styles.title}> {book.title} </h2>
                <p className={styles.description}> {book.description} </p>
            </div>
        </div>
    );


};

export default Modal;





