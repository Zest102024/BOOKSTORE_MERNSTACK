
import BookItem from "./BookItem";


const BookList = ({books, onBookClick}) => {

    return (
        <div style={{display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "20px"}}>
            {books.map((book) => (
                <BookItem key={book.id} book={book} onBookClick={onBookClick} />
            )
        )}
        </div>
    );

};

export default BookList;