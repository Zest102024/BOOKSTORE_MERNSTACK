import styles from "../styles/rentbook.module.css";

const SearchBar = ({searchTerm, setSearchTerm}) => {

    return (
        <input 
        type= "text"
        placeholder="Search for a book..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className={styles["search-bar"]}/>

    );


};

export default SearchBar;