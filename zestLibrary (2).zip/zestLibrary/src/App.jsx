import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Layout from "./component/Layout";
import Home from "./component/Home";
import ManageAccount from "./component/ManageAccount";
import RentBook from "./component/RentBook";
import Locations from "./component/Locations";
import SignIn from "./component/SignIn";
import SignUp from "./component/SignUp";

const router = createBrowserRouter([
  {
    element: <Layout />,
    children: [
      {
        path: "/",
        element: <Home />,
      },
      {
        path: "/manage-account",
        element: <ManageAccount />,
      },
      {
        path: "/rent-book",
        element: <RentBook />,
      },
      {
        path: "/locations",
        element: <Locations />,
      },
      {
        path: "/signin",
        element: <SignIn />
      },
      {
        path: "/signup",
        element: <SignUp />
      },
    ],
  },
]);


const App = () => {
  return (
    <RouterProvider router={router} />
  

  );
};

export default App;
